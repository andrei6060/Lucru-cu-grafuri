#include "list.h"

List initList()
{
	List list;

	list = (List) malloc(sizeof(struct list));
	list->next = NULL;
	return list;
}



